create function delete_property_type_index(p_table_name character varying, p_id_index bigint) returns void
  security definer
  language plpgsql
as
$$
declare
    v_index_name varchar;
begin
    v_index_name := 'activity.IDX_HSTORE_' || substring(p_table_name from 12) || '_' || p_id_index::text; -- The 'activity.' schema prefix is kept
    EXECUTE 'DROP INDEX ' || v_index_name;
end;
$$;

alter function delete_property_type_index(varchar, bigint) owner to postgres;

