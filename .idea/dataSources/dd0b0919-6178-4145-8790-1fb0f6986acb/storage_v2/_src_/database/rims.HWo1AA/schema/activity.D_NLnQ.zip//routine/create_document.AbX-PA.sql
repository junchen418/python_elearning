create function create_document(p_name character varying, p_description character varying, p_object_type_id character varying, p_properties hstore, p_mime_type character varying, p_filename character varying, p_binary_content bytea, p_file_path character varying, p_binary_content_storage_mode activity.storage_mode, p_user character varying, p_change_log_data hstore) returns bigint
  security definer
  language plpgsql
as
$fun$
declare
    v_base_id activity.Object_Type.base_id%type;
    v_id_document activity.Object_Document.id%type;
    v_change_token activity.Change_Log.id%type;
    v_change_timestamp activity.Change_Log.change_timestamp%type;
	v_is_content_stream boolean := false;
	v_binary_content_length activity.Content_Stream.length%type := null;
	v_document_content_stream_allowed activity.Object_Type.document_content_stream_allowed%type;
	v_binary_content_hash_algorithm activity.Content_Stream.binary_content_hash_algorithm%type := null;
	v_binary_content_hash  activity.Content_Stream.binary_content_hash%type := null;
	v_id_content_stream bigint;
begin
    -- Checking whether the object type is present
    if p_object_type_id is null then
        raise exception $$The object type is mandatory$$;
    end if;

	-- Getting and checking the object type information
    SELECT document_content_stream_allowed
	INTO v_document_content_stream_allowed
	FROM activity.Object_Type
	WHERE id = p_object_type_id;

    -- Getting and checking the object type information
    SELECT base_id
        INTO v_base_id
        FROM activity.Object_Type
        WHERE id = p_object_type_id;
    if not found then
        raise exception $$The object type '%' does not exist$$, p_object_type_id;
    end if;
    if v_base_id != 'cmis:document' then
        raise exception $$The object type '%' must have the 'cmis:document' base type$$, p_object_type_id;
    end if;

    -- Checking the properties
    PERFORM activity.check_object_properties(p_object_type_id, p_properties);

    if p_mime_type is not null or p_filename is not null or p_binary_content is not null or p_file_path is null or p_binary_content_storage_mode is not null then
        if p_mime_type is null or p_filename is null or (p_binary_content is null and p_file_path is null) or p_binary_content_storage_mode is null then
            raise exception $$Inconsistent set of content stream information$$;
        end if;
	end if;

	 if v_document_content_stream_allowed = 'required' and (p_binary_content is null or p_file_path is null) then
        raise exception $$Content stream information is required for object type '%'$$, p_object_type_id;
    end if;

    if p_binary_content_storage_mode = 'in_external_system' and p_file_path is null then
      raise exception $$File path information is required when binary_content_storage_mode = '%'$$, p_binary_content_storage_mode;
    end if;

    if p_binary_content_storage_mode = 'in_bytea' and p_binary_content is null then
      raise exception $$Binary content information is required when binary_content_storage_mode = '%'$$, p_binary_content_storage_mode;
    end if;

    -- Setting the new document ID
    v_id_document := nextval('activity.id_object_seq');

	-- Setting content stream information
    if p_binary_content is not null or p_file_path is not null  then
        v_is_content_stream := true;
        v_id_content_stream := nextval('activity.id_content_stream_seq');
        if p_binary_content_storage_mode = 'in_bytea' then
            v_binary_content_length = octet_length(p_binary_content);
            if v_binary_content_hash_algorithm is null then
                v_binary_content_hash_algorithm := 'sha512';
            end if;
            if v_binary_content_hash is null then
                v_binary_content_hash := digest(p_binary_content, v_binary_content_hash_algorithm::text);
            end if;
        end if;
    end if;

    -- Updating the data
    v_change_token := nextval('activity.id_change_log_seq');
    v_change_timestamp := now();

	if v_is_content_stream = true then
        INSERT INTO activity.Content_Stream (
            id,
            length,
            mime_type,
            filename,
            binary_content,
            file_path,
            binary_content_storage_mode,
            binary_content_hash,
            binary_content_hash_algorithm,
            last_modified_by,
            last_modification_date
        )
        VALUES (
            v_id_content_stream,
            v_binary_content_length,
            p_mime_type,
            p_filename,
            p_binary_content,
            p_file_path,
            p_binary_content_storage_mode,
            v_binary_content_hash,
            v_binary_content_hash_algorithm,
            p_user,
            v_change_timestamp
        );
    end if;

    INSERT INTO activity.Object_Document (
        id,
        name,
        description,
		    content_stream_id,
		    rendition_ids,
        object_type_id,
        created_by,
        creation_date,
        last_modified_by,
        last_modification_date,
        change_token,
        properties
    )
    VALUES (
        v_id_document,
        p_name,
        p_description,
		v_id_content_stream,
		null,
        p_object_type_id,
        p_user,
        v_change_timestamp,
        p_user,
        v_change_timestamp,
        v_change_token,
        p_properties
    );

    INSERT INTO activity.Change_Log (
        id,
        change_timestamp,
        changed_by,
        change_type,
        changed_object_id,
        data
    )
    VALUES (
        v_change_token,
        v_change_timestamp,
        p_user,
        'created',
        v_id_document,
        p_change_log_data
    );

    return v_id_document;

end;
$fun$;

alter function create_document(varchar, varchar, varchar, hstore, varchar, varchar, bytea, varchar, activity.storage_mode, varchar, hstore) owner to postgres;

