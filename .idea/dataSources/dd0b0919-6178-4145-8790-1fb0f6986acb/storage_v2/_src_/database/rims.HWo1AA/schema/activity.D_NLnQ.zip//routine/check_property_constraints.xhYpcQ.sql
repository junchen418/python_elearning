create function check_property_constraints(p_property_type activity.property_type, p_string_max_length integer, p_string_pattern text, p_number_min_value text, p_number_max_value text, p_decimal_precision activity.property_decimal_precision, p_datetime_resolution activity.property_datetime_resolution) returns void
  security definer
  language plpgsql
as
$fun$
begin
    -- Checking "string_max_length"
    if p_string_max_length is not null then
        if p_property_type != 'string' then
            raise exception $$The 'string_max_length' applies only to 'string' properties$$;
        end if;
        if p_string_max_length < 1 then
            raise exception $$The 'string_max_length' must be strictly positive$$;
        end if;
    end if;
    
    -- Checking "string_pattern"
    if p_string_pattern is not null then
        if p_property_type != 'string' then
            raise exception $$The 'string_pattern' applies only to 'string' properties$$;
        end if;
        begin
            PERFORM '' ~ p_string_pattern;
        exception
            when invalid_regular_expression then
                raise exception $$The 'string_pattern' is not a valid regular expression$$;
        end;
    end if;
    
    -- Checking "number_min_value"
    if p_number_min_value is not null then
        if p_property_type not in ('decimal', 'integer') then
            raise exception $$The 'number_min_value' applies only to 'decimal'/'integer' properties$$;
        end if;
        if p_property_type = 'decimal' and p_number_min_value !~ '^-?[0-9]+([.][0-9]+)?$' then
            raise exception $$The 'number_min_value' is not a valid 'decimal' number$$;
        end if;
        if p_property_type = 'integer' and p_number_min_value !~ '^-?[0-9]+$' then
            raise exception $$The 'number_min_value' is not a valid 'integer' number$$;
        end if;
    end if;
    
    -- Checking "number_max_value"
    if p_number_max_value is not null then
        if p_property_type not in ('decimal', 'integer') then
            raise exception $$The 'number_max_value' applies only to 'decimal'/'integer' properties$$;
        end if;
        if p_property_type = 'decimal' and p_number_max_value !~ '^-?[0-9]+([.][0-9]+)?$' then
            raise exception $$The 'number_max_value' is not a valid 'decimal' number$$;
        end if;
        if p_property_type = 'integer' and p_number_max_value !~ '^-?[0-9]+$' then
            raise exception $$The 'number_max_value' is not a valid 'integer' number$$;
        end if;
    end if;
    
    -- Checking "decimal_precision"
    if p_decimal_precision is not null then
        if p_property_type != 'decimal' then
            raise exception $$The 'decimal_precision' applies only to 'decimal' properties$$;
        end if;
    end if;
    
    -- Checking "datetime_resolution"
    if p_datetime_resolution is not null then
        if p_property_type != 'datetime' then
            raise exception $$The 'datetime_resolution' applies only to 'datetime' properties$$;
        end if;
    end if;
    
end;
$fun$;

alter function check_property_constraints(activity.property_type, integer, text, text, text, activity.property_decimal_precision, activity.property_datetime_resolution) owner to postgres;

