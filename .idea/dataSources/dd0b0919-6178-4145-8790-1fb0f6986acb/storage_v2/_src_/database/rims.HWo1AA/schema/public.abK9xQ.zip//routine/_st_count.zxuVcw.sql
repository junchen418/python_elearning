create function "_st_count"(rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, sample_percent double precision DEFAULT 1) returns bigint
  immutable
  strict
  parallel safe
  language plpgsql
as
$$
DECLARE
		rtn bigint;
	BEGIN
		IF exclude_nodata_value IS FALSE THEN
			SELECT width * height INTO rtn FROM public.ST_Metadata(rast);
		ELSE
			SELECT count INTO rtn FROM public._ST_summarystats($1, $2, $3, $4);
		END IF;

		RETURN rtn;
	END;

$$;

alter function "_st_count"(raster, integer, boolean, double precision) owner to postgres;

