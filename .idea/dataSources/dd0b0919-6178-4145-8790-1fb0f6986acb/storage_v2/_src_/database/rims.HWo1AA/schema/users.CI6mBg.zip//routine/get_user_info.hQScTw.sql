create function get_user_info(p_session_token character varying) returns users.user_info
  security definer
  language plpgsql
as
$$
declare
	v_id_user users.User.id%type;
	v_first_name users.User.first_name%type;
    v_last_name users.User.last_name%type;
    v_email users.User.email%type;
    v_receives_emails users.User.receives_emails%type;
    v_attributes users.User.attributes%type;
    v_entities varchar[];
	v_id_entity varchar;
    v_attributes_entity hstore;
    v_roles varchar[];
    v_id_role varchar;
    v_permissions varchar[];
    v_id_permission varchar;
	v_result users.user_info;
begin
	select u.id, u.first_name, u.last_name, u.email, u.receives_emails, u.attributes
	into v_id_user, v_first_name, v_last_name, v_email, v_receives_emails, v_attributes
	from users.session s
	JOIN users.user u ON s.user_id = u.id
	where s.session_token = p_session_token;

	-- Bad ID
    if not found then
        v_result := ROW('invalid', null, null, null, null, null, null, null, null, null);
        return v_result;
    end if;

    -- Getting the user's entities
    v_entities := ARRAY[]::varchar[];
    for v_id_entity in
        SELECT DISTINCT id_entity FROM users.User_Entity_Link
        WHERE id_user = v_id_user
        ORDER BY id_entity loop

        v_entities := array_append(v_entities, v_id_entity);
    end loop;

    select entity.attributes
    into v_attributes_entity
    from users.User_Entity_Link link
    JOIN users.entity entity ON link.id_entity = entity.id
    where link.id_user = v_id_user;

    -- Getting the user's roles
    v_roles := ARRAY[]::varchar[];
    for v_id_role in
        SELECT DISTINCT id_role FROM users.User_Role_Link
        WHERE id_user = v_id_user or id_user in (
            SELECT id_user from users.User_Delegate_User_Link
            WHERE id_delegate_user = v_id_user
            and ( delegation_start is null or delegation_start <= now() )
            and ( delegation_end is null or delegation_end >= now() )
        )
        ORDER BY id_role loop

        v_roles := array_append(v_roles, v_id_role);
    end loop;

    -- Getting the user's permissions
    v_permissions := ARRAY[]::varchar[];
    for v_id_permission in
        SELECT DISTINCT id_permission FROM users.Role_Permission_Link
        WHERE id_role in (
            SELECT id_role FROM users.User_Role_Link
            WHERE id_user = v_id_user or id_user in (
                SELECT id_user from users.User_Delegate_User_Link
                WHERE id_delegate_user = v_id_user
                and ( delegation_start is null or delegation_start <= now() )
                and ( delegation_end is null or delegation_end >= now() )
            )
        )
        ORDER BY id_permission loop

        v_permissions := array_append(v_permissions, v_id_permission);
    end loop;
    if v_attributes is null then v_attributes := v_attributes_entity; else
      v_attributes := v_attributes || v_attributes_entity;
    end if;
	v_result := ROW('valid', v_id_user, v_first_name, v_last_name, v_email, v_receives_emails, v_attributes, v_entities, v_roles, v_permissions);
	return v_result;
end;
$$;

alter function get_user_info(varchar) owner to postgres;

