create function update_item(p_id_item bigint, p_name character varying, p_description character varying, p_properties hstore, p_user character varying, p_change_log_data hstore) returns void
  security definer
  language plpgsql
as
$fun$
declare
    v_object_type_id activity.Object_Item.object_type_id%type;
    v_change_token activity.Change_Log.id%type;
    v_change_timestamp activity.Change_Log.change_timestamp%type;
begin
    -- Locking the item
    PERFORM activity.lock_object(p_id_item, 'cmis:item');

    -- Getting and checking the item information
    SELECT object_type_id
        INTO v_object_type_id
        FROM activity.Object_Item
        WHERE id = p_id_item;
    if not found then
        raise exception $$The item '%' does not exist$$, p_id_item;
    end if;

    -- Checking the properties
    PERFORM activity.check_object_properties(v_object_type_id, p_properties);

    -- Updating the data
    v_change_token := nextval('activity.id_change_log_seq');
    v_change_timestamp := now();

    UPDATE activity.Object_Item SET
        name = p_name,
        description = p_description,
        properties = p_properties,
        last_modified_by = p_user,
        last_modification_date = v_change_timestamp,
        change_token = v_change_token
        WHERE id = p_id_item;

    INSERT INTO activity.Change_Log (
        id,
        change_timestamp,
        changed_by,
        change_type,
        changed_object_id,
        data
    )
    VALUES (
        v_change_token,
        v_change_timestamp,
        p_user,
        'updated',
        p_id_item,
        p_change_log_data
    );

end;
$fun$;

alter function update_item(bigint, varchar, varchar, hstore, varchar, hstore) owner to postgres;

