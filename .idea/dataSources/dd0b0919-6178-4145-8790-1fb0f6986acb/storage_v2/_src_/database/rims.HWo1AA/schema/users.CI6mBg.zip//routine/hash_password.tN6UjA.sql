create function hash_password(p_password character varying, p_is_password_already_hashed boolean) returns character varying
  security definer
  language plpgsql
as
$$
begin
    if p_is_password_already_hashed = true then
        return p_password;
    else
        return crypt(p_password::text, gen_salt('bf', 8))::varchar;
    end if;
end;
$$;

alter function hash_password(varchar, boolean) owner to postgres;

