create function delete_role(p_id_role character varying, p_change_log_changed_by character varying, p_change_log_data hstore) returns users.role_management_info
  security definer
  language plpgsql
as
$$
declare
    v_users_count bigint;
    v_result users.role_management_info;
    v_change_token users.Change_Log.id%type;
    v_change_timestamp users.Change_Log.change_timestamp%type;
begin
    -- Locking the role
    PERFORM users.lock_object(p_id_role, 'role');

    -- Checking whether there are associated users
    SELECT count(*)
        INTO v_users_count
        FROM users.User_Role_Link
        WHERE id_role = p_id_role;
    if v_users_count > 0 then
        v_result := ROW('associated_users');
        return v_result;
    end if;

    -- Updating the data
    v_change_token := nextval('users.id_change_log_seq');
    v_change_timestamp := now();

    DELETE FROM users.Role WHERE id = p_id_role;

    INSERT INTO users.Change_Log (
        id,
        change_timestamp,
        changed_by,
        change_type,
        changed_object_id,
        changed_object_type,
        data
    )
    VALUES (
        v_change_token,
        v_change_timestamp,
        p_change_log_changed_by,
        'deleted',
        p_id_role,
        'role',
        p_change_log_data
    );

    v_result := ROW('role_deletion_success');
    return v_result;

end;
$$;

alter function delete_role(varchar, varchar, hstore) owner to postgres;

