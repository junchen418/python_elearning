create function login(p_id_user character varying, p_password character varying, p_new_password character varying, p_is_password_already_hashed boolean, p_password_life_max interval, p_bad_login_tolerance interval) returns users.login_info
  security definer
  language plpgsql
as
$$
declare
    v_password_hash users.User.password%type;
    v_password_change_timestamp users.User.password_change_timestamp%type;
    v_last_access_timestamp users.session.last_access%type;
    v_is_active users.User.is_active%type;
    v_is_locked users.User.is_locked%type;
    v_bad_logins users.User.bad_logins%type;
    v_first_name users.User.first_name%type;
    v_last_name users.User.last_name%type;
    v_email users.User.email%type;
    v_receives_emails users.User.receives_emails%type;
    v_attributes users.User.attributes%type;
    v_attributes_entity users.entity.attributes%type;
    v_entities varchar[];
    v_id_entity varchar;
    v_area_id text;
    v_roles varchar[];
    v_id_role varchar;
    v_permissions varchar[];
    v_id_permission varchar;
    v_result users.login_info;
    v_password_update_info users.user_management_info;
begin
    -- Getting the user information
    SELECT password, password_change_timestamp, is_active, is_locked, bad_logins, first_name, last_name, email, receives_emails, attributes
        INTO v_password_hash, v_password_change_timestamp, v_is_active, v_is_locked, v_bad_logins, v_first_name, v_last_name, v_email, v_receives_emails, v_attributes
        FROM users.User
        WHERE id = p_id_user;

    -- Bad ID
    if not found then
        v_result := ROW('login_error', null, null, null, null, null, null, null, null, null);
        return v_result;
    end if;

    SELECT last_access
    INTO v_last_access_timestamp
    FROM users.session
    WHERE user_id = p_id_user
    ORDER BY last_access desc
    LIMIT 1;

    if found then
        if now() < v_last_access_timestamp + '5 min'::interval then
            v_result := ROW('logged_user', null, null, null, null, null, null, null, null, null);
            return v_result;
        end if;
    end if;

    -- Getting the user's entities
    v_entities := ARRAY[]::varchar[];
    for v_id_entity in
        SELECT DISTINCT id_entity FROM users.User_Entity_Link
        WHERE id_user = p_id_user
        ORDER BY id_entity loop

        v_entities := array_append(v_entities, v_id_entity);
    end loop;

    select entity.attributes
    into v_attributes_entity
    from users.User_Entity_Link link
    JOIN users.entity entity ON link.id_entity = entity.id
    where link.id_user = p_id_user;

    -- Getting the user's roles
    v_roles := ARRAY[]::varchar[];
    for v_id_role in
        SELECT DISTINCT id_role FROM users.User_Role_Link
        WHERE id_user = p_id_user or id_user in (
            SELECT id_user from users.User_Delegate_User_Link
            WHERE id_delegate_user = p_id_user
            and ( delegation_start is null or delegation_start <= now() )
            and ( delegation_end is null or delegation_end >= now() )
        )
        ORDER BY id_role loop

        v_roles := array_append(v_roles, v_id_role);
    end loop;

    -- Getting the user's permissions
    v_permissions := ARRAY[]::varchar[];
    for v_id_permission in
        SELECT DISTINCT id_permission FROM users.Role_Permission_Link
        WHERE id_role in (
            SELECT id_role FROM users.User_Role_Link
            WHERE id_user = p_id_user or id_user in (
                SELECT id_user from users.User_Delegate_User_Link
                WHERE id_delegate_user = p_id_user
                and ( delegation_start is null or delegation_start <= now() )
                and ( delegation_end is null or delegation_end >= now() )
            )
        )
        ORDER BY id_permission loop

        v_permissions := array_append(v_permissions, v_id_permission);
    end loop;

    -- Good ID and good password
    if ( p_is_password_already_hashed = true and v_password_hash = p_password )
    or ( (p_is_password_already_hashed is null or p_is_password_already_hashed = false) and v_password_hash = crypt(p_password, v_password_hash) ) then
        if ( now() - v_password_change_timestamp ) > coalesce(p_password_life_max, interval '3 months') then
            if p_new_password is null or p_new_password = '' then
                v_result := ROW('expired_password', null, null, null, null, null, null, null, null, null);
            else
                v_password_update_info = users.update_user(p_id_user, 'password_only', p_new_password, p_is_password_already_hashed,
                                                                null, null, null, null, null, null, null, null, interval '0 days',
                                                                p_id_user, hstore('expired_password', null));
                if v_password_update_info.status = 'invalid_password' then
                    v_result := ROW('invalid_new_password', null, null, null, null, null, null, null, null, null);
                elsif v_password_update_info.status = 'recently_used_password' then
                    v_result := ROW('recently_used_new_password', null, null, null, null, null, null, null, null, null);
                else
                    if v_attributes is null then v_attributes := v_attributes_entity; else
                      v_attributes := v_attributes || v_attributes_entity;
                    end if;
                    v_result := ROW('login_success', v_first_name, v_last_name, v_email, v_receives_emails, v_attributes, v_entities, v_roles, v_permissions, users.get_new_session_token(p_id_user, v_roles, v_permissions));
                end if;
            end if;
            return v_result;
        elsif v_is_active = false then
            v_result := ROW('inactive_user', null, null, null, null, null, null, null, null, null);
            return v_result;
        elsif v_is_locked = true then
            v_result := ROW('locked_user', null, null, null, null, null, null, null, null, null);
            return v_result;
        else
            if v_attributes is null then v_attributes := v_attributes_entity; else
              v_attributes := v_attributes || v_attributes_entity;
            end if;
            v_result := ROW('login_success', v_first_name, v_last_name, v_email, v_receives_emails, v_attributes, v_entities, v_roles, v_permissions, users.get_new_session_token(p_id_user, v_roles, v_permissions));
            return v_result;
        end if;
    end if;

    -- Good ID and bad password: updating the bad logins and locking the user if there were 3 bad logins within the tolerance period
    if v_bad_logins is null then
        v_bad_logins := ARRAY[now()]::timestamp with time zone[];
    elsif coalesce(array_length(v_bad_logins, 1), 0) < 3 then
        v_bad_logins := array_append(v_bad_logins, now());
    else
        v_bad_logins := array_append(v_bad_logins[2:3], now());
    end if;
    if coalesce(array_length(v_bad_logins, 1), 0) = 3 and ( v_bad_logins[3] - v_bad_logins[1] ) <= coalesce(p_bad_login_tolerance, interval '30 minutes') then
        v_is_locked := true;
    end if;

    UPDATE users.User SET
        is_locked = v_is_locked,
        bad_logins = v_bad_logins
        WHERE id = p_id_user;

    v_result := ROW('login_error', null, null, null, null, null, null, null, null, null);
    return v_result;

end;
$$;

alter function login(varchar, varchar, varchar, boolean, interval, interval) owner to postgres;

