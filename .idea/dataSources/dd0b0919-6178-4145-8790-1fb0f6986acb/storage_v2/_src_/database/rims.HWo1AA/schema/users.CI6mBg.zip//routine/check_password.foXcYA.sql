create function check_password(p_password character varying) returns boolean
  security definer
  language plpgsql
as
$$
declare
    v_is_uppercase boolean := false;
    v_is_lowercase boolean := false;
    v_is_digit boolean := false;
begin
    return true;
    if p_password is null or char_length(p_password) < 8 or char_length(p_password) > 12 then
        return false;
    end if;

    if p_password ~ '[A-Z]' then
        v_is_uppercase := true;
    end if;

    if p_password ~ '[a-z]' then
        v_is_lowercase := true;
    end if;

    if p_password ~ '[0-9]' then
        v_is_digit := true;
    end if;

    if v_is_uppercase = true and (v_is_lowercase = true or v_is_digit = true) then
        return true;
    else
        return false;
    end if;

end;
$$;

alter function check_password(varchar) owner to postgres;

