create function calculate_total_pbdt() returns trigger
  language plpgsql
as
$$
BEGIN
  IF new.total ISNULL
  THEN
    UPDATE stats.patent_count_pbdt
    SET total = coalesce(new.cnb, 0) + coalesce(new.cnu, 0) + coalesce(new.cnd, 0)
    WHERE id = new.id;
  END IF;
  IF new.total_cumul ISNULL
  THEN
    UPDATE stats.patent_count_pbdt
    SET total_cumul = coalesce(new.cnb_cumul, 0) + coalesce(new.cnu_cumul, 0) + coalesce(new.cnd_cumul, 0)
    WHERE id = new.id;
  END IF;
  RETURN new;
END;
$$;

alter function calculate_total_pbdt() owner to postgres;

