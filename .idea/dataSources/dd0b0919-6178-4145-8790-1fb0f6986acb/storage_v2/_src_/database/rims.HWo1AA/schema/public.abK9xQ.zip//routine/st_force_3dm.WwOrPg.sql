create function st_force_3dm(geometry) returns geometry
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public._postgis_deprecate('ST_Force_3dm', 'ST_Force3DM', '2.1.0');
    SELECT public.ST_Force3DM($1);
$$;

alter function st_force_3dm(geometry) owner to postgres;

