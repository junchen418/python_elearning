create function update_document(p_id_document bigint, p_name character varying, p_description character varying, p_properties hstore, p_user character varying, p_change_log_data hstore) returns void
  security definer
  language plpgsql
as
$fun$
declare
    v_object_type_id activity.Object_Document.object_type_id%type;
    v_change_token activity.Change_Log.id%type;
    v_change_timestamp activity.Change_Log.change_timestamp%type;
begin
    -- Locking the document
    PERFORM activity.lock_object(p_id_document, 'cmis:document');

    -- Getting and checking the document information
    SELECT object_type_id
        INTO v_object_type_id
        FROM activity.Object_Document
        WHERE id = p_id_document;
    if not found then
        raise exception $$The document '%' does not exist$$, p_id_document;
    end if;

    -- Checking the properties
    PERFORM activity.check_object_properties(v_object_type_id, p_properties);

    -- Updating the data
    v_change_token := nextval('activity.id_change_log_seq');
    v_change_timestamp := now();

    UPDATE activity.Object_Document SET
        name = p_name,
        description = p_description,
        properties = p_properties,
        last_modified_by = p_user,
        last_modification_date = v_change_timestamp,
        change_token = v_change_token
        WHERE id = p_id_document;

    INSERT INTO activity.Change_Log (
        id,
        change_timestamp,
        changed_by,
        change_type,
        changed_object_id,
        data
    )
    VALUES (
        v_change_token,
        v_change_timestamp,
        p_user,
        'updated',
        p_id_document,
        p_change_log_data
    );

end;
$fun$;

alter function update_document(bigint, varchar, varchar, hstore, varchar, hstore) owner to postgres;

