create function get_division_of_point(p_latitude character varying, p_longitude character varying, p_level integer) returns bigint
  language plpgsql
as
$$
DECLARE v_id BIGINT;
	DECLARE v_geo FLOAT[];
	begin
		SELECT stat.bd09_to_wgs84(p_longitude::DOUBLE PRECISION, p_latitude::DOUBLE PRECISION) INTO v_geo;
		select max(id)
		into v_id
		from stat.admin_division ad
		where ST_Contains(polygon, ST_SetSRID(ST_Point(v_geo [1], v_geo [2]), 3857)) and level = p_level;
-- 		select max(id)
-- 		into v_id
-- 		from stat.admin_division ad
-- 		where st_intersects(ad.polygon, ST_GeomFromText('POINT('||p_longitude||' '||p_latitude||')',3857)) and level = p_level;
		return v_id;
	end;
$$;

alter function get_division_of_point(varchar, varchar, integer) owner to postgres;

