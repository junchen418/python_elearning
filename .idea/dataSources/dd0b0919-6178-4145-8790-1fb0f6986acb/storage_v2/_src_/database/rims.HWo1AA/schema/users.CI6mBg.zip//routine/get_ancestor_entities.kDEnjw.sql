create function get_ancestor_entities(p_id_user character varying) returns SETOF users.ancestor_entity_info
  security definer
  language sql
as
$$
WITH RECURSIVE entity_hierarchy AS (
        SELECT 0 AS level, a.id_entity AS id
        FROM users.User_Entity_Link a
        WHERE a.id_user = p_id_user
        UNION ALL
        SELECT b.level+1, a.parent_id
        FROM users.Entity a, entity_hierarchy b
        WHERE a.id = b.id and a.parent_id is not null
    )
    SELECT
        a.level,
        b.id,
        b.name,
        b.description,
        b.parent_id,
        b.attributes
    FROM entity_hierarchy a, users.Entity b
    WHERE a.id = b.id
$$;

alter function get_ancestor_entities(varchar) owner to postgres;

