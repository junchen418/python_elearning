create function get_object_type_properties(p_object_type_id character varying) returns SETOF activity.property_type_definition
  security definer
  language sql
as
$$
SELECT
        c.id,
        c.id_index,
        c.property_type,
        c.cardinality,
        b.local_name,
        b.display_name,
        b.description,
        b.required,
        b.choices,
        b.open_choice,
        b.default_value,
        b.string_max_length,
        b.string_pattern,
        b.number_min_value,
        b.number_max_value,
        b.decimal_precision,
        b.datetime_resolution
    FROM activity.Property_Type_Link b, activity.Property_Type_Basic c
    WHERE b.id_property_type_basic = c.id and b.id_object_type = p_object_type_id
$$;

alter function get_object_type_properties(varchar) owner to postgres;

