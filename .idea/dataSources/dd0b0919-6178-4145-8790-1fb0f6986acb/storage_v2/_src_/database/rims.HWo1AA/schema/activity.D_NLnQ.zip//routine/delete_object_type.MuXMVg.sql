create function delete_object_type(p_id character varying) returns void
  security definer
  language plpgsql
as
$fun$
declare
    v_base_id activity.Object_Type.base_id%type;
    v_table_name varchar;
    v_col_name varchar;
    v_objects_count bigint;
    v_id_property_type_basic activity.Property_Type_Basic.id%type;
begin
    -- Locking the object type
    PERFORM activity.lock_object_type(p_id);

    -- Getting and checking the object type information
    SELECT base_id
        INTO v_base_id
        FROM activity.Object_Type
        WHERE id = p_id;
    if not found then
        raise exception $$The object type '%' does not exist$$, p_id;
    end if;

    v_table_name := 'activity.Object_' || substring(v_base_id::text from 6);
    v_col_name := 'object_type_id';

    EXECUTE 'SELECT count(*) FROM ' || v_table_name || ' WHERE ' || v_col_name || ' = $1'
        INTO v_objects_count
        USING p_id;
    if v_objects_count > 0 then
        raise exception $$The object type '%' cannot be deleted because it has instantiated objects$$, p_id;
    end if;

    -- Deleting the associated properties
    for v_id_property_type_basic in SELECT id_property_type_basic FROM activity.Property_Type_Link WHERE id_object_type = p_id loop
        PERFORM activity.delete_property_type_internal(p_id, v_id_property_type_basic, true);
    end loop;

    -- Deleting the object type
    DELETE FROM activity.Object_Type WHERE id = p_id;

end;
$fun$;

alter function delete_object_type(varchar) owner to postgres;

