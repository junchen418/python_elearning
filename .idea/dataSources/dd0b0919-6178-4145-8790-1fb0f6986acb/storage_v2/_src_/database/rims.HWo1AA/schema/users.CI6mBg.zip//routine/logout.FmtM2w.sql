create function logout(p_session_token character varying) returns void
  security definer
  language plpgsql
as
$$
begin
  DELETE FROM users.session where session_token = p_session_token;
end;
$$;

alter function logout(varchar) owner to postgres;

