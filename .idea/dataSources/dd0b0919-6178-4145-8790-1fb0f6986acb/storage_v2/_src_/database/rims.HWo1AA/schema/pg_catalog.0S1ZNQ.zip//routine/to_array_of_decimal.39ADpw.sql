create function to_array_of_decimal(p_value text) returns numeric[]
  immutable
  strict
  security definer
  language plpgsql
as
$$
declare
    v_value_parts text[];
    v_value_part text;
    v_result decimal[] := ARRAY[]::decimal[];
begin
    -- Iterating over each individual value
    v_value_parts := string_to_array(p_value, '~^~');
    foreach v_value_part in array v_value_parts loop
        v_result := array_append(v_result, v_value_part::decimal);
    end loop;
    
    return v_result;
end;
$$;

alter function to_array_of_decimal(text) owner to postgres;

