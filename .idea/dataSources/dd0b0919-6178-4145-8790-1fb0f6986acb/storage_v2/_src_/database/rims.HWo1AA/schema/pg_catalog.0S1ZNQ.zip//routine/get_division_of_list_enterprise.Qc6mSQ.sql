create function get_division_of_list_enterprise(p_ids character varying, p_level integer) returns bigint[]
  language plpgsql
as
$$
declare v_id bigint;
		v_id_array bigint[];
		v_latitude varchar;
		v_longitude varchar;
		v_ids_division bigint[];
begin
	v_ids_division :=  '{}';
	v_id_array := string_to_array(p_ids ,',');
	for v_latitude, v_longitude in
		select (regexp_matches(properties->'rims:lat_lng', '\((.*) ','g'))[1],(regexp_matches(properties->'rims:lat_lng', ' (.*)\)','g'))[1]
		from activity.object_item where object_type_id = 'rims:assignee' and id = ANY(v_id_array) and properties->'rims:assignee_type' = 'COMPANY'
	LOOP
		select stat.get_division_of_point(v_latitude, v_longitude, p_level) into v_id;
		v_ids_division := array_append(v_ids_division, v_id);
	end loop;

	return v_ids_division;
end;
$$;

alter function get_division_of_list_enterprise(varchar, integer) owner to postgres;

