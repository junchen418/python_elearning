create function create_user(p_id_user character varying, p_password character varying, p_is_password_already_hashed boolean, p_first_name character varying, p_last_name character varying, p_email character varying, p_receives_emails boolean, p_attributes hstore, p_entities character varying[], p_roles character varying[], p_change_log_changed_by character varying, p_change_log_data hstore) returns users.user_management_info
  security definer
  language plpgsql
as
$fun$
declare
    v_password users.User.password%type;
    v_password_hash users.User.password%type;
    v_result users.user_management_info;
    v_id_entity varchar;
    v_id_role varchar;
    v_change_token users.Change_Log.id%type;
    v_change_timestamp users.Change_Log.change_timestamp%type;
begin
    -- Checking whether the user ID is present
    if p_id_user is null then
        raise exception $$The user ID is mandatory$$;
    end if;

    -- Generating (if missing) or checking the password
    v_password := p_password;
    v_password_hash := users.hash_password(v_password, p_is_password_already_hashed);
    if v_password is null then
        v_password := users.generate_password();
        v_password_hash := users.hash_password(v_password, false);
    elsif (p_is_password_already_hashed is null or p_is_password_already_hashed = false) and users.check_password(v_password) = false then
        v_result := ROW('invalid_password', v_password);
        return v_result;
    end if;

    -- Updating the data
    v_change_token := nextval('users.id_change_log_seq');
    v_change_timestamp := now();

    begin
        INSERT INTO users.User (
            id,
            password,
            password_change_timestamp,
            last_passwords,
            is_active,
            is_locked,
            bad_logins,
            first_name,
            last_name,
            email,
            receives_emails,
            change_token,
            attributes
        )
        VALUES (
            p_id_user,
            v_password_hash,
            v_change_timestamp,
            ARRAY[v_password_hash]::varchar[],
            true,
            false,
            null,
            p_first_name,
            p_last_name,
            p_email,
            p_receives_emails,
            v_change_token,
            p_attributes
        );
    exception
        when unique_violation then
            v_result := ROW('unavailable_user_id', v_password);
            return v_result;
    end;

    DELETE FROM users.User_Entity_Link WHERE id_user = p_id_user;
    if p_entities is not null then
        foreach v_id_entity in array p_entities loop
            INSERT INTO users.User_Entity_Link (id_entity, id_user) VALUES (v_id_entity, p_id_user);
        end loop;
    end if;

    DELETE FROM users.User_Role_Link WHERE id_user = p_id_user;
    if p_roles is not null then
        foreach v_id_role in array p_roles loop
            INSERT INTO users.User_Role_Link (id_role, id_user) VALUES (v_id_role, p_id_user);
        end loop;
    end if;

    INSERT INTO users.Change_Log (
        id,
        change_timestamp,
        changed_by,
        change_type,
        changed_object_id,
        changed_object_type,
        data
    )
    VALUES (
        v_change_token,
        v_change_timestamp,
        p_change_log_changed_by,
        'created',
        p_id_user,
        'user',
        p_change_log_data
    );
    v_result := ROW('user_creation_success', v_password);
    return v_result;

end;
$fun$;

alter function create_user(varchar, varchar, boolean, varchar, varchar, varchar, boolean, hstore, character varying[], character varying[], varchar, hstore) owner to postgres;

