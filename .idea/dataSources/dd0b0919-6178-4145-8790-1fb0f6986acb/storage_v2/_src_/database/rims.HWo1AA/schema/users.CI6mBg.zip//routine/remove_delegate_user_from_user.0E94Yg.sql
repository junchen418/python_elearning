create function remove_delegate_user_from_user(p_id_user character varying, p_id_delegate_user character varying, p_change_log_changed_by character varying, p_change_log_data hstore) returns users.user_management_info
  security definer
  language plpgsql
as
$$
declare
    v_result users.user_management_info;
    v_change_token users.Change_Log.id%type;
    v_change_timestamp users.Change_Log.change_timestamp%type;
begin
    -- Locking the user and the delegate user
    PERFORM users.lock_object(p_id_user, 'user');
    PERFORM users.lock_object(p_id_delegate_user, 'user');

    -- Updating the data
    DELETE FROM users.User_Delegate_User_Link WHERE id_user = p_id_user and id_delegate_user = p_id_delegate_user;
    if not found then
        v_result := ROW('unapplied_delegation', null);
        return v_result;
    end if;

    v_change_token := nextval('users.id_change_log_seq');
    v_change_timestamp := now();

    UPDATE users.User SET
        change_token = v_change_token
        WHERE id = p_id_user;

    INSERT INTO users.Change_Log (
        id,
        change_timestamp,
        changed_by,
        change_type,
        changed_object_id,
        changed_object_type,
        data
    )
    VALUES (
        v_change_token,
        v_change_timestamp,
        p_change_log_changed_by,
        'updated',
        p_id_user,
        'user',
        p_change_log_data
    );

    v_result := ROW('user_update_success', null);
    return v_result;

end;
$$;

alter function remove_delegate_user_from_user(varchar, varchar, varchar, hstore) owner to postgres;

