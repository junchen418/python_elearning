create function update_industry_assignee_rank() returns void
  language plpgsql
as
$$
DECLARE
  v_area BIGINT;
BEGIN
  TRUNCATE stats.industry_assignee_rank;
  select id into v_area from stat.admin_division where name_local = '昆山市';
  CREATE TEMP TABLE assignee_tmp(name VARCHAR, ans_id varchar, class varchar);
  INSERT INTO assignee_tmp
  SELECT name, properties->'rims:ans_id', regexp_split_to_table(properties->'rims:class', '~\^~')
  FROM activity.object_item
  WHERE object_type_id = 'rims:assignee';
  INSERT INTO stats.industry_assignee_rank(area, name, ans_id, figure, rank, type, class)
    SELECT v_area, name, ans_id, figure, rank() OVER (PARTITION BY class ORDER BY figure DESC), 'company_patent_count', class
    FROM (
           SELECT name, ans_id, count(patent_id) figure, class
           FROM assignee_tmp
             JOIN tmp.kunshan_patent USING (ans_id)
           WHERE class ~ '^kunshan'
           GROUP BY ans_id, name, class) t;
  INSERT INTO stats.industry_assignee_rank(area, name, ans_id, figure, rank, type, class)
    SELECT v_area, name, ans_id, figure, rank() OVER (PARTITION BY class ORDER BY figure DESC), 'company_patent_value', class
    FROM (
           SELECT name, ans_id, sum(coalesce((min + max)/2, 0)) figure, class
           FROM assignee_tmp
             JOIN tmp.kunshan_patent USING (ans_id)
           WHERE class ~ '^kunshan'
           GROUP BY ans_id, name, class) t;
  INSERT INTO stats.industry_assignee_rank(area, code, name, pbdt, ans_id, figure, rank, type, class)
    SELECT v_area, pn, title, pbdt, ans_id, figure, rank() OVER (PARTITION BY class ORDER BY figure DESC), 'patent_value', class
    FROM (
           SELECT pn, title, pbdt, ans_id, coalesce((min + max)/2, 0) figure, class
           FROM assignee_tmp
             JOIN tmp.kunshan_patent USING (ans_id)
           WHERE class ~ '^kunshan') t;
END;
$$;

alter function update_industry_assignee_rank() owner to postgres;

