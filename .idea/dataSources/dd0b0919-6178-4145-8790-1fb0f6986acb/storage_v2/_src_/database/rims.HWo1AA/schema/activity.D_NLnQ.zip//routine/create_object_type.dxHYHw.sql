create function create_object_type(p_id character varying, p_base_id activity.base_type, p_local_name character varying, p_display_name character varying, p_description text, p_document_content_stream_allowed activity.document_content_stream_allowed) returns void
  security definer
  language plpgsql
as
$fun$
begin

	-- Checking the "document_content_stream_allowed" flag
    if p_document_content_stream_allowed is not null and p_base_id != 'cmis:document' then
        raise exception $$Content stream configuration applies only to documents$$;
    elsif p_document_content_stream_allowed is null and p_base_id = 'cmis:document' then
        raise exception $$Content stream configuration is mandatory for documents$$;
    end if;

    -- Inserting the object type
    INSERT INTO activity.Object_Type (
        id,
		base_id,
        local_name,
        display_name,
        description
    )
    VALUES (
        p_id,
		p_base_id,
        p_local_name,
        p_display_name,
        p_description
    );
end;
$fun$;

alter function create_object_type(varchar, activity.base_type, varchar, varchar, text, activity.document_content_stream_allowed) owner to postgres;

