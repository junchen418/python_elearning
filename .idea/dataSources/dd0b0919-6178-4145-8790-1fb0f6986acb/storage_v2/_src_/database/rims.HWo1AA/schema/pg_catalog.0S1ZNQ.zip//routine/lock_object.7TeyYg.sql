create function lock_object(p_id character varying, p_type object_type) returns void
  security definer
  language plpgsql
as
$fun$
begin
    -- Checking the type
    if p_type is null then
        raise exception $$The type is mandatory$$;
    end if;

    -- Lock of the object
    if p_type = 'user' then
        PERFORM id FROM users.User WHERE id = p_id FOR UPDATE;
    elsif p_type = 'entity' then
        PERFORM id FROM users.Entity WHERE id = p_id FOR UPDATE;
    elsif p_type = 'role' then
        PERFORM id FROM users.Role WHERE id = p_id FOR UPDATE;
    elsif p_type = 'permission' then
        PERFORM id FROM users.Permission WHERE id = p_id FOR UPDATE;
    else
        raise exception $$The object type '%' does not exist$$, p_type;
    end if;
    if not found then
        raise exception $$The object '%' does not exist (type '%')$$, p_id, p_type;
    end if;
end;
$fun$;

alter function lock_object(varchar, object_type) owner to postgres;

