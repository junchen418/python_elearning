create function calculate_total_apdt() returns trigger
  language plpgsql
as
$$
BEGIN
  IF new.total ISNULL
  THEN
    UPDATE stats.patent_count_apdt
    SET total = coalesce(new.cna, 0) + coalesce(new.cnu, 0) + coalesce(new.cnd, 0)
    WHERE id = new.id;
  END IF;
  IF new.total_cumul ISNULL
  THEN
    UPDATE stats.patent_count_apdt
    SET total_cumul = coalesce(new.cna_cumul, 0) + coalesce(new.cnu_cumul, 0) + coalesce(new.cnd_cumul, 0)
    WHERE id = new.id;
  END IF;
  RETURN new;
END;
$$;

alter function calculate_total_apdt() owner to postgres;

