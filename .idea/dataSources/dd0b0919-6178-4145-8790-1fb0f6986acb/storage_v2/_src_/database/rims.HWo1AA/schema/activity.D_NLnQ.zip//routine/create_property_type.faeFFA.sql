create function create_property_type(p_id_object_type character varying, p_id_property_type_basic character varying, p_property_type activity.property_type, p_cardinality activity.property_cardinality, p_local_name character varying, p_display_name character varying, p_description text, p_required boolean, p_choices activity.property_choice[], p_open_choice boolean, p_default_value text, p_string_max_length integer, p_string_pattern text, p_number_min_value text, p_number_max_value text, p_decimal_precision activity.property_decimal_precision, p_datetime_resolution activity.property_datetime_resolution) returns void
  security definer
  language plpgsql
as
$fun$
declare
	v_base_id activity.Object_Type.base_id%type;
    v_table_name varchar;
    v_col_name varchar;
    v_objects_count bigint;
    v_create_property_type_basic boolean := true;
    v_id_index activity.Property_Type_Basic.id_index%type;
    v_property_type activity.Property_Type_Basic.property_type%type;
    v_cardinality activity.Property_Type_Basic.cardinality%type;
    v_choice activity.property_choice;
    v_id_object_type activity.Object_Type.id%type;
    v_index_count integer;
begin

    -- Locking the object type
    PERFORM activity.lock_object_type(p_id_object_type);

	 -- Getting and checking the object type information
    SELECT base_id
        INTO v_base_id
        FROM activity.Object_Type
        WHERE id = p_id_object_type;
    if not found then
        raise exception $$The object type '%' does not exist$$, p_id_object_type;
    end if;

	v_table_name := 'activity.Object_' || substring(v_base_id::text from 6);
	v_col_name := 'object_type_id' ;

	if p_required = true and p_default_value is null then
		raise exception $$The object type '%' cannot be updated because the added property type '%' is required without default value$$, p_id_object_type, p_id_property_type_basic;
	end if;

    -- Checking whether the property type ID is present
    if p_id_property_type_basic is null then
        raise exception $$The property type ID is mandatory$$;
    end if;

    -- Getting and checking the property type basic information
    SELECT id_index, property_type, cardinality
        INTO v_id_index, v_property_type, v_cardinality
        FROM activity.Property_Type_Basic
        WHERE id = p_id_property_type_basic FOR UPDATE;
    if found then
        v_create_property_type_basic := false;
        if p_property_type != v_property_type then
            raise exception $$The 'property_type' must be '%' for property type '%'$$, v_property_type, p_id_property_type_basic;
        end if;
        if p_cardinality != v_cardinality then
            raise exception $$The 'cardinality' must be '%' for property type '%'$$, v_cardinality, p_id_property_type_basic;
        end if;
    else
        v_id_index := nextval('activity.id_index_seq');
    end if;

    -- Checking the property constraints
    PERFORM activity.check_property_constraints(p_property_type,
                                                p_string_max_length, p_string_pattern,
                                                p_number_min_value, p_number_max_value,
                                                p_decimal_precision,
                                                p_datetime_resolution
                                            );

    -- Checking the "choices" field
    if p_choices is not null then
        foreach v_choice in array p_choices loop
            if v_choice.display_name is null or v_choice.level is null or v_choice.value is null then
                raise exception $$Not all fields are set in composite field '%'$$, v_choice;
            end if;
            PERFORM activity.check_property_value(v_choice.value, p_id_property_type_basic, p_property_type, p_cardinality, p_required,
                                                    null, null,
                                                    p_string_max_length, p_string_pattern,
                                                    p_number_min_value, p_number_max_value,
                                                    p_decimal_precision,
                                                    p_datetime_resolution
                                                );
        end loop;
    end if;

    -- Checking the "open_choice" flag
    if p_open_choice is null and p_choices is not null then
        raise exception $$The 'open_choice' flag is mandatory when the 'choices' field is set$$;
    elsif p_open_choice is not null and p_choices is null then
        raise exception $$The 'open_choice' flag is prohibited when the 'choices' field is not set$$;
    end if;

    -- Checking the "default_value" field
    if p_default_value is not null then
        PERFORM activity.check_property_value(p_default_value, p_id_property_type_basic, p_property_type, p_cardinality, p_required,
                                                p_choices, p_open_choice,
                                                p_string_max_length, p_string_pattern,
                                                p_number_min_value, p_number_max_value,
                                                p_decimal_precision,
                                                p_datetime_resolution
                                            );
    end if;

    -- Inserting the property type
    if v_create_property_type_basic = true then
        INSERT INTO activity.Property_Type_Basic (
            id,
            id_index,
            property_type,
            cardinality
        )
        VALUES (
            p_id_property_type_basic,
            v_id_index,
            p_property_type,
            p_cardinality
        );
        PERFORM activity.lock_property_type(p_id_property_type_basic);
    end if;

    INSERT INTO activity.Property_Type_Link (
        id_object_type,
        id_property_type_basic,
        local_name,
        display_name,
        description,
        required,
        choices,
        open_choice,
        default_value,
        string_max_length,
        string_pattern,
        number_min_value,
        number_max_value,
        decimal_precision,
        datetime_resolution
    )
    VALUES (
        p_id_object_type,
        p_id_property_type_basic,
        p_local_name,
        p_display_name,
        p_description,
        p_required,
        p_choices,
        p_open_choice,
        p_default_value,
        p_string_max_length,
        p_string_pattern,
        p_number_min_value,
        p_number_max_value,
        p_decimal_precision,
        p_datetime_resolution
    );

	PERFORM activity.check_all_objects_properties(p_id_object_type);

    -- Updating the objects
    if p_required = true and p_default_value is not null then
        EXECUTE 'UPDATE ' || v_table_name || ' SET properties = properties || hstore($2, $3) WHERE ( not defined(properties, $2) ) and  ' || v_col_name || ' = $1 '
            USING p_id_object_type, p_id_property_type_basic, p_default_value;
    end if;

	 -- Creating (if necessary) an index for the property
	SELECT count(*)
		INTO v_index_count
		FROM activity.Object_Type a, activity.Property_Type_Link b
		WHERE a.id = b.id_object_type and a.base_id = v_base_id and b.id_property_type_basic = p_id_property_type_basic ;
	if v_index_count = 1 then
		PERFORM activity.create_property_type_index(v_table_name, v_id_index, p_id_property_type_basic, p_property_type, p_cardinality);
	end if;

end;
$fun$;

alter function create_property_type(varchar, varchar, activity.property_type, activity.property_cardinality, varchar, varchar, text, boolean, activity.property_choice[], boolean, text, integer, text, text, text, activity.property_decimal_precision, activity.property_datetime_resolution) owner to postgres;

