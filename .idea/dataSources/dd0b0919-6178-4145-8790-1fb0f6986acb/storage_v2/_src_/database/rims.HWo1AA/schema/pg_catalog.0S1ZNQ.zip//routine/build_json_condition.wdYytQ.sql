create function build_json_condition(p_table_name character varying, p_params character varying[], prefix character varying DEFAULT ''::character varying) returns text
  language plpgsql
as
$$
declare v_keys varchar[];
		v_length int;
		v_key varchar;
		v_value varchar;
		v_text text;
begin
	EXECUTE 'SELECT array_agg(key)
	FROM (
	SELECT distinct jsonb_object_keys(conditions) as key from ' || p_table_name ||
	') a;' INTO v_keys;

	v_text := ' 1=1 ';

	if prefix <> '' then
		prefix := prefix || '.';
	end if;

	v_length := array_length(p_params,1);

	if v_length%2<>0 or v_length =0 then
		raise exception 'parameter p_params % should not be empty and be pair', p_params;
	end if;

	for i in 1 .. v_length BY 2 loop
		v_key := p_params[i];
		v_value := p_params[i+1];
		if not v_key = ANY( v_keys ) then
			raise exception 'key % is not in conditions'' key set', v_key;
		end if;

		v_text := v_text || ' and '||prefix||'conditions->>'''||v_key ||''' = '''||v_value||''' ';
		v_keys := array_remove(v_keys, v_key);
	end loop;

	for i in 1 .. array_length(v_keys,1) loop
		v_text := v_text || ' and coalesce('||prefix||'conditions->>''' ||v_keys[i] || ''', '''') ='''' ' ;
	end loop;

	return v_text;

end;
$$;

alter function build_json_condition(varchar, character varying[], varchar) owner to postgres;

