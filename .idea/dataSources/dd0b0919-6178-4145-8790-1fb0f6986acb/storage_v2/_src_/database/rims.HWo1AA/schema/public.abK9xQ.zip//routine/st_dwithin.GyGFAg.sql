create function st_dwithin(geography, geography, double precision, boolean) returns boolean
  immutable
  parallel safe
  language sql
as
$$
SELECT $1 OPERATOR(public.&&) public._ST_Expand($2,$3) AND $2 OPERATOR(public.&&) public._ST_Expand($1,$3) AND public._ST_DWithin($1, $2, $3, $4)
$$;

comment on function st_dwithin(geography, geography, double precision, boolean) is 'args: gg1, gg2, distance_meters, use_spheroid - Returns true if the geometries are within the specified distance of one another. For geometry units are in those of spatial reference and For geography units are in meters and measurement is defaulted to use_spheroid=true (measure around spheroid), for faster check, use_spheroid=false to measure along sphere.';

alter function st_dwithin(geography, geography, double precision, boolean) owner to postgres;

