create function create_item(p_name character varying, p_description character varying, p_object_type_id character varying, p_properties hstore, p_user character varying, p_change_log_data hstore) returns bigint
  security definer
  language plpgsql
as
$fun$
declare
    v_base_id activity.Object_Type.base_id%type;
    v_id_item activity.Object_Item.id%type;
    v_change_token activity.Change_Log.id%type;
    v_change_timestamp activity.Change_Log.change_timestamp%type;
begin
    -- Checking whether the object type is present
    if p_object_type_id is null then
        raise exception $$The object type is mandatory$$;
    end if;

    -- Getting and checking the object type information
    SELECT base_id
        INTO v_base_id
        FROM activity.Object_Type
        WHERE id = p_object_type_id;
    if not found then
        raise exception $$The object type '%' does not exist$$, p_object_type_id;
    end if;

    -- Checking the properties
    PERFORM activity.check_object_properties(p_object_type_id, p_properties);

    -- Updating the data
    v_id_item := nextval('activity.id_object_seq');
    v_change_token := nextval('activity.id_change_log_seq');
    v_change_timestamp := now();

    INSERT INTO activity.Object_Item (
        id,
        name,
        description,
        object_type_id,
        created_by,
        creation_date,
        last_modified_by,
        last_modification_date,
        change_token,
        properties
    )
    VALUES (
        v_id_item,
        p_name,
        p_description,
        p_object_type_id,
        p_user,
        v_change_timestamp,
        p_user,
        v_change_timestamp,
        v_change_token,
        p_properties
    );

    INSERT INTO activity.Change_Log (
        id,
        change_timestamp,
        changed_by,
        change_type,
        changed_object_id,
        data
    )
    VALUES (
        v_change_token,
        v_change_timestamp,
        p_user,
        'created',
        v_id_item,
        p_change_log_data
    );

    return v_id_item;

end;
$fun$;

alter function create_item(varchar, varchar, varchar, hstore, varchar, hstore) owner to postgres;

