create function update_user(p_id_user character varying, p_update_type users.user_update_type, p_password character varying, p_is_password_already_hashed boolean, p_is_active boolean, p_first_name character varying, p_last_name character varying, p_email character varying, p_receives_emails boolean, p_attributes hstore, p_entities character varying[], p_roles character varying[], p_password_life_min interval, p_change_log_changed_by character varying, p_change_log_data hstore) returns users.user_management_info
  security definer
  language plpgsql
as
$fun$
declare
    v_password_change_timestamp users.User.password_change_timestamp%type;
    v_last_passwords users.User.last_passwords%type;
    v_password users.User.password%type := null;
    v_password_hash users.User.password%type;
    v_result users.user_management_info;
    v_id_entity varchar;
    v_id_role varchar;
    v_change_token users.Change_Log.id%type;
    v_change_timestamp users.Change_Log.change_timestamp%type;
begin
    -- Locking the user
    PERFORM users.lock_object(p_id_user, 'user');

    -- Checking the update type
    if p_update_type is null then
        raise exception $$The update type is mandatory$$;
    end if;

    -- Getting the user information
    SELECT password_change_timestamp, last_passwords
        INTO v_password_change_timestamp, v_last_passwords
        FROM users.User
        WHERE id = p_id_user;
    if not found then
        raise exception $$The user '%' does not exist$$, p_id_user;
    end if;

    -- Generating (if missing) or checking the password
    if p_update_type in ('everything', 'password_only') then
        v_password := p_password;
        v_password_hash := users.hash_password(v_password, p_is_password_already_hashed);
        if v_password is null then
            v_password := users.generate_password();
            v_password_hash := users.hash_password(v_password, false);
        elsif (p_is_password_already_hashed is null or p_is_password_already_hashed = false) and users.check_password(v_password) = false then
            v_result := ROW('invalid_password', v_password);
            return v_result;
        elsif users.is_recently_used_password(v_password, p_is_password_already_hashed, v_last_passwords) = true and 1=2 then
            v_result := ROW('recently_used_password', v_password);
            return v_result;
        elsif ( now() - v_password_change_timestamp ) < coalesce(p_password_life_min, interval '1 second') then
            v_result := ROW('recently_changed_password', v_password);
            return v_result;
        end if;
        if coalesce(array_length(v_last_passwords, 1), 0) < 5 then
            v_last_passwords := array_append(v_last_passwords, v_password_hash);
        else
            v_last_passwords := array_append(v_last_passwords[2:5], v_password_hash);
        end if;
    end if;

    -- Updating the data
    v_change_token := nextval('users.id_change_log_seq');
    v_change_timestamp := now();

    if p_update_type = 'everything' then
        UPDATE users.User SET
            password = v_password_hash,
            password_change_timestamp = v_change_timestamp,
            last_passwords = v_last_passwords,
            is_active = p_is_active,
            first_name = p_first_name,
            last_name = p_last_name,
            email = p_email,
            receives_emails = p_receives_emails,
            change_token = v_change_token,
            attributes = p_attributes
            WHERE id = p_id_user;
          DELETE FROM users.Session WHERE user_id = p_id_user;

    elsif p_update_type = 'everything_except_password' then
        UPDATE users.User SET
            is_active = p_is_active,
            first_name = p_first_name,
            last_name = p_last_name,
            email = p_email,
            receives_emails = p_receives_emails,
            change_token = v_change_token,
            attributes = p_attributes
            WHERE id = p_id_user;

    elsif p_update_type = 'password_only' then
        UPDATE users.User SET
            password = v_password_hash,
            password_change_timestamp = v_change_timestamp,
            last_passwords = v_last_passwords,
            change_token = v_change_token
            WHERE id = p_id_user;
        DELETE FROM users.Session WHERE user_id = p_id_user;

    else
        raise exception $$Bad update type$$;
    end if;

    if p_update_type in ('everything', 'everything_except_password') then
        DELETE FROM users.User_Entity_Link WHERE id_user = p_id_user;
        if p_entities is not null then
            foreach v_id_entity in array p_entities loop
                INSERT INTO users.User_Entity_Link (id_entity, id_user) VALUES (v_id_entity, p_id_user);
            end loop;
        end if;

        DELETE FROM users.User_Role_Link WHERE id_user = p_id_user;
        if p_roles is not null then
            foreach v_id_role in array p_roles loop
                INSERT INTO users.User_Role_Link (id_role, id_user) VALUES (v_id_role, p_id_user);
            end loop;
        end if;
    end if;

    INSERT INTO users.Change_Log (
        id,
        change_timestamp,
        changed_by,
        change_type,
        changed_object_id,
        changed_object_type,
        data
    )
    VALUES (
        v_change_token,
        v_change_timestamp,
        p_change_log_changed_by,
        'updated',
        p_id_user,
        'user',
        p_change_log_data
    );

    v_result := ROW('user_update_success', v_password);
    return v_result;

end;
$fun$;

alter function update_user(varchar, users.user_update_type, varchar, boolean, boolean, varchar, varchar, varchar, boolean, hstore, character varying[], character varying[], interval, varchar, hstore) owner to postgres;

