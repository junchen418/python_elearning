create function setdbinfo() returns void
  language plpgsql
as
$$
declare v_seq int;
      v_change_time timestamptz;
      v_count int;
begin
  select count(*) into v_count from dbinfo;
  if v_count = 0 then
    insert into dbinfo values(0, now());
      return ;
  end if;

  select seq, change_time into v_seq, v_change_time from dbinfo order by seq desc limit 1;

  v_seq = v_seq + 1;

  insert into dbinfo values(v_seq, now());
end;
$$;

alter function setdbinfo() owner to postgres;

