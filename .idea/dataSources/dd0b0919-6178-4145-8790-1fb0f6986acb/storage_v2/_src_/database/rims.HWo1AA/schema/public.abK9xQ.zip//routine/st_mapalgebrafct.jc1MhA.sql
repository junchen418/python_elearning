create function st_mapalgebrafct(rast raster, band integer, pixeltype text, onerastuserfunc regprocedure) returns raster
  immutable
  parallel safe
  language sql
as
$$
SELECT public.ST_mapalgebrafct($1, $2, $3, $4, NULL)
$$;

alter function st_mapalgebrafct(raster, integer, text, regprocedure) owner to postgres;

