create function check_all_objects_properties(p_object_type_id character varying) returns void
  security definer
  language plpgsql
as
$fun$
declare
    v_base_id activity.Object_Type.base_id%type;
    v_table_name varchar;
    v_col1_name varchar;
    v_col2_name varchar;
    v_id bigint;
    v_properties hstore;
begin
    -- Getting the base type
    SELECT base_id 
        INTO v_base_id 
        FROM activity.Object_Type 
        WHERE id = p_object_type_id;
    if not found then
        raise exception $$The object type '%' does not exist$$, p_object_type_id;
    end if;
    
    -- Iterating over the objects
    v_table_name := 'activity.Object_' || substring(v_base_id::text from 6);
    v_col1_name := 'id' ;
    v_col2_name := 'object_type_id' ;
    for v_id, v_properties in EXECUTE 'SELECT ' || v_col1_name || ', properties FROM ' || v_table_name || ' WHERE ' || v_col2_name || ' = $1'
                            USING p_object_type_id loop
        begin
            PERFORM activity.check_object_properties(p_object_type_id, v_properties);
        exception
            when others then
                raise exception $$Error for object '%' (base type '%'): %$$, v_id, v_base_id, sqlerrm;
        end;
    end loop;
end;
$fun$;

alter function check_all_objects_properties(varchar) owner to postgres;

