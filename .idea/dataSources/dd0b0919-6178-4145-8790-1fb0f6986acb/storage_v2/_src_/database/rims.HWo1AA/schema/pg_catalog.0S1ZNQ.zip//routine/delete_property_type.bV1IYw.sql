create function delete_property_type(p_id_object_type character varying, p_id_property_type_basic character varying) returns void
  security definer
  language plpgsql
as
$$
begin
    PERFORM activity.delete_property_type_internal(p_id_object_type, p_id_property_type_basic, false);
end;
$$;

alter function delete_property_type(varchar, varchar) owner to postgres;

