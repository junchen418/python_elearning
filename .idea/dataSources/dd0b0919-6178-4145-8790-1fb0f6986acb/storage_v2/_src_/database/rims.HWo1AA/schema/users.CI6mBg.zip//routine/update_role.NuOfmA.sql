create function update_role(p_id_role character varying, p_name character varying, p_description text, p_attributes hstore, p_permissions character varying[], p_change_log_changed_by character varying, p_change_log_data hstore) returns users.role_management_info
  security definer
  language plpgsql
as
$$
declare
    v_result users.role_management_info;
    v_id_permission varchar;
    v_change_token users.Change_Log.id%type;
    v_change_timestamp users.Change_Log.change_timestamp%type;
begin
    -- Locking the role
    PERFORM users.lock_object(p_id_role, 'role');

    -- Updating the data
    v_change_token := nextval('users.id_change_log_seq');
    v_change_timestamp := now();

    UPDATE users.Role SET
        name = p_name,
        description = p_description,
        change_token = v_change_token,
        attributes = p_attributes
        WHERE id = p_id_role;

    DELETE FROM users.Role_Permission_Link WHERE id_role = p_id_role;
    if p_permissions is not null then
        foreach v_id_permission in array p_permissions loop
            INSERT INTO users.Role_Permission_Link (id_permission, id_role) VALUES (v_id_permission, p_id_role);
        end loop;
    end if;

    INSERT INTO users.Change_Log (
        id,
        change_timestamp,
        changed_by,
        change_type,
        changed_object_id,
        changed_object_type,
        data
    )
    VALUES (
        v_change_token,
        v_change_timestamp,
        p_change_log_changed_by,
        'updated',
        p_id_role,
        'role',
        p_change_log_data
    );

    v_result := ROW('role_update_success');
    return v_result;

end;
$$;

alter function update_role(varchar, varchar, text, hstore, character varying[], varchar, hstore) owner to postgres;

