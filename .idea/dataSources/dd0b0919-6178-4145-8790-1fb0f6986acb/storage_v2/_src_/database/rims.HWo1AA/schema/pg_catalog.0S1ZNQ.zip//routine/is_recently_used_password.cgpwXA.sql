create function is_recently_used_password(p_password character varying, p_is_password_already_hashed boolean, p_last_passwords character varying[]) returns boolean
  security definer
  language plpgsql
as
$$
declare
    v_password_hash varchar;
begin
    foreach v_password_hash in array p_last_passwords loop
        if p_is_password_already_hashed = true and v_password_hash = p_password then
            return true;
        elsif (p_is_password_already_hashed is null or p_is_password_already_hashed = false) and v_password_hash = crypt(p_password, v_password_hash) then
            return true;
        end if;
    end loop;

    return false;
end;
$$;

alter function is_recently_used_password(varchar, boolean, character varying[]) owner to postgres;

