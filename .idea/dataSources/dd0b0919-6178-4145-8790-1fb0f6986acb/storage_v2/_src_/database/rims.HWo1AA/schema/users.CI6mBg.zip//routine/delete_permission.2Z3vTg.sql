create function delete_permission(p_id_permission character varying, p_change_log_changed_by character varying, p_change_log_data hstore) returns users.permission_management_info
  security definer
  language plpgsql
as
$$
declare
    v_roles_count bigint;
    v_result users.permission_management_info;
    v_change_token users.Change_Log.id%type;
    v_change_timestamp users.Change_Log.change_timestamp%type;
begin
    -- Locking the permission
    PERFORM users.lock_object(p_id_permission, 'permission');

    -- Checking whether there are associated roles
    SELECT count(*)
        INTO v_roles_count
        FROM users.Role_Permission_Link
        WHERE id_permission = p_id_permission;
    if v_roles_count > 0 then
        v_result := ROW('associated_roles');
        return v_result;
    end if;

    -- Updating the data
    v_change_token := nextval('users.id_change_log_seq');
    v_change_timestamp := now();

    DELETE FROM users.Permission WHERE id = p_id_permission;

    INSERT INTO users.Change_Log (
        id,
        change_timestamp,
        changed_by,
        change_type,
        changed_object_id,
        changed_object_type,
        data
    )
    VALUES (
        v_change_token,
        v_change_timestamp,
        p_change_log_changed_by,
        'deleted',
        p_id_permission,
        'permission',
        p_change_log_data
    );

    v_result := ROW('permission_deletion_success');
    return v_result;

end;
$$;

alter function delete_permission(varchar, varchar, hstore) owner to postgres;

