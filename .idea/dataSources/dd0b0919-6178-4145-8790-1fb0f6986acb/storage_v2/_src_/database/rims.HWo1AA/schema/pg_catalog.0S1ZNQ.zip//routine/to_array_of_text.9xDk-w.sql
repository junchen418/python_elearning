create function to_array_of_text(p_value text) returns text[]
  immutable
  strict
  security definer
  language plpgsql
as
$$
begin
    return string_to_array(p_value, '~^~');
end;
$$;

alter function to_array_of_text(text) owner to postgres;

