create function check_object_properties(p_object_type_id character varying, p_properties hstore) returns void
  security definer
  language plpgsql
as
$fun$
declare
    v_record record;
begin
    for v_record in SELECT * FROM activity.get_object_type_properties(p_object_type_id) a
                             FULL OUTER JOIN each(p_properties) b on b.key = a.id loop
        if v_record.id is null then
            raise exception $$Property '%' is not defined$$, v_record.key;
        end if;
        if substring(v_record.id for 5) = 'cmis:' and v_record.value is not null then
            raise exception $$Property '%' cannot be set via the hstore$$, v_record.id;
        end if;
        if substring(v_record.id for 5) != 'cmis:' then
            PERFORM activity.check_property_value(
                v_record.value,
                v_record.id,
                v_record.property_type,
                v_record.cardinality,
                v_record.required,
                v_record.choices,
                v_record.open_choice,
                v_record.string_max_length,
                v_record.string_pattern,
                v_record.number_min_value,
                v_record.number_max_value,
                v_record.decimal_precision,
                v_record.datetime_resolution
            );
        end if;
    end loop;
end;
$fun$;

alter function check_object_properties(varchar, hstore) owner to postgres;

