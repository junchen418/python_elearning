create function check_session_token(p_session_token character varying, p_timeout interval, p_required_roles character varying[], p_required_permissions character varying[], p_session_life_max interval DEFAULT NULL::interval) returns boolean
  security definer
  language plpgsql
as
$$
begin
    DELETE FROM users.Session WHERE now() > last_access + p_timeout;
    if p_session_life_max is not null then
        DELETE FROM users.Session WHERE now() > creation_date + p_session_life_max;
    end if;
    UPDATE users.Session
        SET last_access = now()
        WHERE session_token = p_session_token
            and ( p_required_roles is null or p_required_roles <@ roles )
            and ( p_required_permissions is null or p_required_permissions <@ permissions );

    if not found then
        return false;
    else
        return true;
    end if;
end;
$$;

alter function check_session_token(varchar, interval, character varying[], character varying[], interval) owner to postgres;

