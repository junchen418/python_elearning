create function unlockrows(text) returns integer
  strict
  language plpgsql
as
$$
DECLARE
	ret int;
BEGIN

	IF NOT LongTransactionsEnabled() THEN
		RAISE EXCEPTION 'Long transaction support disabled, use EnableLongTransaction() to enable.';
	END IF;

	EXECUTE 'DELETE FROM authorization_table where authid = ' ||
		quote_literal($1);

	GET DIAGNOSTICS ret = ROW_COUNT;

	RETURN ret;
END;
$$;

comment on function unlockrows(text) is 'args: auth_token - Remove all locks held by specified authorization id. Returns the number of locks released.';

alter function unlockrows(text) owner to postgres;

