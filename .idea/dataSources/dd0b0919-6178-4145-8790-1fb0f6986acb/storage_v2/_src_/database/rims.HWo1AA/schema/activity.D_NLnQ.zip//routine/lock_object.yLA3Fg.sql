create function lock_object(p_id bigint, p_base_type_id activity.base_type) returns void
  security definer
  language plpgsql
as
$fun$
declare
    v_table_name varchar;
    v_row_count integer;
begin
    -- Checking the base type
    if p_base_type_id is null then
        raise exception $$The base type is mandatory$$;
    end if;

    -- Checking the object ID
    if p_id is null then
        raise exception $$The object ID is mandatory (base type '%')$$, p_base_type_id;
    end if;
    
    -- Versionable document: lock of the associated version series
    -- Non-versionable document: lock of the document
    if p_base_type_id = 'cmis:document' then
		PERFORM id FROM activity.Object_Document WHERE id = p_id FOR UPDATE;
		if not found then
			raise exception $$The document '%' does not exist$$, p_id;
		end if;    
    -- Other object types: lock of the object
    else
        v_table_name := 'activity.Object_' || substring(p_base_type_id::text from 6);
        EXECUTE 'SELECT id FROM ' || v_table_name || ' WHERE id = $1 FOR UPDATE'
            USING p_id;
        get diagnostics v_row_count = row_count;
        if v_row_count = 0 then
            raise exception $$The object '%' does not exist (base type '%')$$, p_id, p_base_type_id;
        end if;
    end if;
end;
$fun$;

alter function lock_object(bigint, activity.base_type) owner to postgres;

