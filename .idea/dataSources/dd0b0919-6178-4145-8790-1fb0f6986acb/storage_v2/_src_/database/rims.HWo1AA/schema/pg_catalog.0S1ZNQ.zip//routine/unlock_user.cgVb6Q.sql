create function unlock_user(p_id_user character varying) returns void
  security definer
  language plpgsql
as
$$
begin
    -- Unlocking the user
    UPDATE users.User SET
        is_locked = false,
        bad_logins = null
        WHERE id = p_id_user;

end;
$$;

alter function unlock_user(varchar) owner to postgres;

