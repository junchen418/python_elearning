create function delete_property_type_internal(p_id_object_type character varying, p_id_property_type_basic character varying, p_inside_object_type_deletion boolean) returns void
  security definer
  language plpgsql
as
$fun$
declare
    v_base_id activity.Object_Type.base_id%type;
    v_table_name varchar;
    v_col_name varchar;
    v_objects_count bigint;
    v_delete_property_type_basic boolean := false;
    v_id_index activity.Property_Type_Basic.id_index%type;
    v_cardinality activity.Property_Type_Basic.cardinality%type;
    v_property_type_link_count integer;
    v_id_object_type activity.Object_Type.id%type;
    v_index_count integer;
begin
	-- Locking the object type and the property type
    PERFORM activity.lock_object_type(p_id_object_type);
    PERFORM activity.lock_property_type(p_id_property_type_basic);

    -- Getting and checking the object type information
    SELECT base_id
        INTO v_base_id
        FROM activity.Object_Type
        WHERE id = p_id_object_type;
    if not found then
        raise exception $$The object type '%' does not exist$$, p_id_object_type;
    end if;

    v_table_name := 'activity.Object_' || substring(v_base_id::text from 6);
    v_col_name := 'object_type_id' ;

    -- Getting and checking the property type information
    SELECT a.id_index, a.cardinality
        INTO v_id_index, v_cardinality
        FROM activity.Property_Type_Basic a, activity.Property_Type_Link b
        WHERE a.id = b.id_property_type_basic and b.id_object_type = p_id_object_type and b.id_property_type_basic = p_id_property_type_basic;
    if not found then
        raise exception $$The object type '%' does not have the property type '%'$$, p_id_object_type, p_id_property_type_basic;
    end if;
    SELECT count(*)
        INTO v_property_type_link_count
        FROM activity.Property_Type_Link
        WHERE id_object_type != p_id_object_type and id_property_type_basic = p_id_property_type_basic;
    if v_property_type_link_count = 0 then
        v_delete_property_type_basic := true;
    end if;

    -- Deleting the property type
    DELETE FROM activity.Property_Type_Link WHERE id_object_type = p_id_object_type and id_property_type_basic = p_id_property_type_basic;

    if v_delete_property_type_basic = true then
        DELETE FROM activity.Property_Type_Basic WHERE id = p_id_property_type_basic;
    end if;

    -- Updating the objects
    EXECUTE 'UPDATE ' || v_table_name || ' SET properties = delete(properties, $2) WHERE ' || v_col_name || ' = $1'
        USING p_id_object_type, p_id_property_type_basic;

    -- Deleting (if necessary) an index for the property
	SELECT count(*)
		INTO v_index_count
		FROM activity.Object_Type a, activity.Property_Type_Link b
		WHERE a.id = b.id_object_type and a.base_id = v_base_id and b.id_property_type_basic = p_id_property_type_basic;
	if v_index_count = 0 then
		PERFORM activity.delete_property_type_index(v_table_name, v_id_index);
	end if;

end;
$fun$;

alter function delete_property_type_internal(varchar, varchar, boolean) owner to postgres;

