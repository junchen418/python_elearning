create function generate_password() returns character varying
  security definer
  language plpgsql
as
$$
declare
    v_password varchar := null;
    v_chars varchar := 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
begin
    while v_password is null loop
        v_password := '';
        for idx in 1..(7+ceil(random()*5))::integer loop
            v_password := v_password || substring(v_chars from ceil(random()*char_length(v_chars))::integer for 1);
        end loop;
        if users.check_password(v_password) = false then
            v_password := null;
        end if;
    end loop;

    return v_password;

end;
$$;

alter function generate_password() owner to postgres;

