create function get_new_session_token(p_user_id character varying, p_roles character varying[], p_permissions character varying[]) returns character varying
  security definer
  language plpgsql
as
$$
declare
    v_session_token varchar := null;
begin
    while v_session_token is null loop
        v_session_token := uuid_generate_v4()::varchar;
        begin
            DELETE FROM users.Session WHERE user_id = p_user_id;
            INSERT INTO users.Session (session_token, creation_date, last_access, user_id, roles, permissions) VALUES (v_session_token, now(), now(), p_user_id, p_roles, p_permissions);
        exception
            when unique_violation then
                v_session_token := null;
        end;
    end loop;

    return v_session_token;

end;
$$;

alter function get_new_session_token(varchar, character varying[], character varying[]) owner to postgres;

