create function bd09_to_wgs84(bd_lon double precision, bd_lat double precision) returns double precision[]
  language plpgsql
as
$$
declare x_pi double PRECISION;
			pi DOUBLE PRECISION;
			a DOUBLE PRECISION;
			ee DOUBLE PRECISION;
			x DOUBLE PRECISION;
			y DOUBLE PRECISION;
			z DOUBLE PRECISION;
			theta DOUBLE PRECISION;
			gg_lng DOUBLE PRECISION;
			gg_lat DOUBLE PRECISION;
			dlng DOUBLE PRECISION;
			dlat DOUBLE PRECISION;
			radlat DOUBLE PRECISION;
			magic DOUBLE PRECISION;
			sqrtmagic DOUBLE PRECISION;
			mglat DOUBLE PRECISION;
			mglng DOUBLE PRECISION;

	begin

		x_pi = 3.14159265358979324 * 3000.0 / 180.0 ;
		pi = 3.1415926535897932384626  ;
		a = 6378245.0  ;
		ee = 0.00669342162296594323  ;

		x := bd_lon - 0.0065;
		y := bd_lat - 0.006;
		z := sqrt(x * x + y * y) - 0.00002 * sin(y * x_pi);
		theta := atan2(y, x) - 0.000003 * cos(x * x_pi);
		gg_lng = z * cos(theta);
    gg_lat = z * sin(theta);

		if not (73.66 < gg_lng and gg_lng < 135.05 and 3.86 < gg_lat and gg_lat< 53.55) then
        return ARRAY[gg_lng, gg_lat]::DOUBLE PRECISION[] ;
		end if;
    dlat = stat.transformlat(gg_lng - 105.0, gg_lat - 35.0);
    dlng = stat.transformlng(gg_lng - 105.0, gg_lat - 35.0);
    radlat = gg_lat / 180.0 * pi;
    magic = sin(radlat);
    magic = 1 - ee * magic * magic;
    sqrtmagic = sqrt(magic);
    dlat = (dlat * 180.0) / ((a * (1 - ee)) / (magic * sqrtmagic) * pi);
    dlng = (dlng * 180.0) / (a / sqrtmagic * cos(radlat) * pi);
    mglat = gg_lat + dlat;
    mglng = gg_lng + dlng;
		RETURN ARRAY[gg_lng * 2 - mglng, gg_lat * 2 - mglat]::DOUBLE PRECISION[];
	end;
$$;

alter function bd09_to_wgs84(double precision, double precision) owner to postgres;

