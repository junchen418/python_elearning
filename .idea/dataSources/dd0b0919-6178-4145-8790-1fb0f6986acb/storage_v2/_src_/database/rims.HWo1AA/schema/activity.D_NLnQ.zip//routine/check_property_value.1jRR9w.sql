create function check_property_value(p_value text, p_id character varying, p_property_type activity.property_type, p_cardinality activity.property_cardinality, p_required boolean, p_choices activity.property_choice[], p_open_choice boolean, p_string_max_length integer, p_string_pattern text, p_number_min_value text, p_number_max_value text, p_decimal_precision activity.property_decimal_precision, p_datetime_resolution activity.property_datetime_resolution) returns void
  security definer
  language plpgsql
as
$fun$
declare
    v_value_parts text[];
    v_value_part text;
    v_choice_ok boolean;
    v_choice activity.property_choice;
begin
    -- Checking whether the value is present
    if p_value is null then
        if p_required = true then
            raise exception $$Required property '%' is missing$$, p_id;
        else
            return;
        end if;
    end if;
    
    -- Checking the cardinality
	if p_property_type = 'plaintext' then 
		v_value_parts := ARRAY[p_value];
	else
		v_value_parts := string_to_array(p_value, '~^~');
	end if;
    if p_cardinality = 'single' and coalesce(array_length(v_value_parts, 1), 0) > 1 then
        raise exception $$Value '%' of property '%' cannot be multi$$, p_value, p_id;
    end if;
    if coalesce(array_length(v_value_parts, 1), 0) = 0 then
        v_value_parts := ARRAY[''];
    end if;
    
    -- Checking each individual value
    foreach v_value_part in array v_value_parts loop
        
        -- Checking "choices"
        if p_choices is not null and p_open_choice = false then
            v_choice_ok := false;
            foreach v_choice in array p_choices loop
                if v_value_part = v_choice.value then
                    v_choice_ok := true;
                    exit;
                end if;
            end loop;
            if v_choice_ok = false then
                raise exception $$Value '%' of property '%' does not belong to the allowed choices$$, v_value_part, p_id;
            end if;
        end if;
        
        -- Checking "string"
        if p_property_type = 'string' then
            if p_string_max_length is not null and char_length(v_value_part) > p_string_max_length then
                raise exception $$Value '%' of property '%' cannot have more than % characters$$, v_value_part, p_id, p_string_max_length;
            end if;
            if p_string_pattern is not null and v_value_part !~ p_string_pattern then
                raise exception $$Value '%' of property '%' does not match the pattern '%'$$, v_value_part, p_id, p_string_pattern;
            end if;
        end if;
        
        -- Checking "boolean"
        if p_property_type = 'boolean' then
            if v_value_part !~ '^true|false$' then
                raise exception $$Value '%' of property '%' is not a valid boolean$$, v_value_part, p_id;
            end if;
        end if;
        
        -- Checking "decimal"
        if p_property_type = 'decimal' then
            if v_value_part !~ '^-?[0-9]+([.][0-9]+)?$' then
                raise exception $$Value '%' of property '%' is not a valid decimal number$$, v_value_part, p_id;
            end if;
            if p_number_min_value is not null and v_value_part::decimal < p_number_min_value::decimal then
                raise exception $$Value '%' of property '%' cannot be less than '%'$$, v_value_part, p_id, p_number_min_value;
            end if;
            if p_number_max_value is not null and v_value_part::decimal > p_number_max_value::decimal then
                raise exception $$Value '%' of property '%' cannot be greater than '%'$$, v_value_part, p_id, p_number_max_value;
            end if;
        end if;
        
        -- Checking "integer"
        if p_property_type = 'integer' then
            if v_value_part !~ '^-?[0-9]+$' then
                raise exception $$Value '%' of property '%' is not a valid integer number$$, v_value_part, p_id;
            end if;
            if p_number_min_value is not null and v_value_part::bigint < p_number_min_value::bigint then
                raise exception $$Value '%' of property '%' cannot be less than '%'$$, v_value_part, p_id, p_number_min_value;
            end if;
            if p_number_max_value is not null and v_value_part::bigint > p_number_max_value::bigint then
                raise exception $$Value '%' of property '%' cannot be greater than '%'$$, v_value_part, p_id, p_number_max_value;
            end if;
        end if;
        
        -- Checking "datetime"
        if p_property_type = 'datetime' then
            begin
                PERFORM activity.to_timestamp(v_value_part::varchar);
            exception
                when invalid_datetime_format then
                    raise exception $$Value '%' of property '%' is not a valid datetime$$, v_value_part, p_id;
            end;
        end if;
        
    end loop;
end;
$fun$;

alter function check_property_value(text, varchar, activity.property_type, activity.property_cardinality, boolean, activity.property_choice[], boolean, integer, text, text, text, activity.property_decimal_precision, activity.property_datetime_resolution) owner to postgres;

