create function update_document_content_stream(p_id_document bigint, p_mime_type character varying, p_filename character varying, p_binary_content bytea, p_file_path character varying, p_binary_content_storage_mode activity.storage_mode, p_binary_content_length bigint, p_binary_content_hash bytea, p_binary_content_hash_algorithm activity.hash_algorithm, p_user character varying, p_change_log_data hstore) returns void
  security definer
  language plpgsql
as
$fun$
declare
    v_object_type_id activity.Object_Document.object_type_id%type;
    v_content_stream_id activity.Object_Document.content_stream_id%type;
    v_document_content_stream_allowed activity.Object_Type.document_content_stream_allowed%type;
    v_id_content_stream activity.Content_Stream.id%type := null;
    v_change_token activity.Change_Log.id%type;
    v_change_timestamp activity.Change_Log.change_timestamp%type;
    v_binary_content_length activity.Content_Stream.length%type := null;
    v_binary_content_hash activity.Content_Stream.binary_content_hash%type := null;
    v_binary_content_hash_algorithm activity.Content_Stream.binary_content_hash_algorithm%type := null;
begin
    -- Locking the document
    PERFORM activity.lock_object(p_id_document, 'cmis:document');

    -- Getting and checking the document information
    SELECT object_type_id, content_stream_id
        INTO v_object_type_id, v_content_stream_id
        FROM activity.Object_Document
        WHERE id = p_id_document;
    if not found then
        raise exception $$The document '%' does not exist$$, p_id_document;
    end if;

    -- Getting and checking the object type information
    SELECT document_content_stream_allowed
        INTO  v_document_content_stream_allowed
        FROM activity.Object_Type
        WHERE id = v_object_type_id;
    if not found then
        raise exception $$The object type '%' does not exist$$, v_object_type_id;
    end if;

    -- Checking content stream information
    if p_mime_type is not null or p_filename is not null or p_binary_content is not null or p_file_path is null or p_binary_content_storage_mode is not null then
        if p_mime_type is null or p_filename is null or (p_binary_content is null and p_file_path is null) or p_binary_content_storage_mode is null then
            raise exception $$Inconsistent set of content stream information$$;
        end if;
        if p_binary_content_storage_mode = 'in_bytea' and p_binary_content_length is not null then
            raise exception $$Inconsistent set of content stream information$$;
        end if;
        if p_binary_content_storage_mode != 'in_bytea' and p_binary_content_length is null then
            raise exception $$Inconsistent set of content stream information$$;
        end if;
        if p_binary_content_hash is not null and p_binary_content_hash_algorithm is null then
            raise exception $$Inconsistent set of content stream information$$;
        end if;
        if p_binary_content_storage_mode != 'in_bytea' and p_binary_content_hash is null and p_binary_content_hash_algorithm is not null then
            raise exception $$Inconsistent set of content stream information$$;
        end if;
    else
        if p_binary_content_length is not null or p_binary_content_hash is not null or p_binary_content_hash_algorithm is not null then
            raise exception $$Inconsistent set of content stream information$$;
        end if;
    end if;
    if v_document_content_stream_allowed = 'notallowed' and p_binary_content is not null then
        raise exception $$Content stream information is not allowed for object type '%'$$, v_object_type_id;
    end if;
    if v_document_content_stream_allowed = 'required' and (p_binary_content is null or p_file_path is null) then
         raise exception $$Content stream information is required for object type '%'$$, p_object_type_id;
     end if;

     if p_binary_content_storage_mode = 'in_external_system' and p_file_path is null then
       raise exception $$File path information is required when binary_content_storage_mode = '%'$$, p_binary_content_storage_mode;
     end if;

     if p_binary_content_storage_mode = 'in_bytea' and p_binary_content is null then
       raise exception $$Binary content information is required when binary_content_storage_mode = '%'$$, p_binary_content_storage_mode;
     end if;


    -- Setting content stream information
    if p_binary_content is not null then
        if v_content_stream_id is null then
            v_id_content_stream := nextval('activity.id_content_stream_seq');
        else
            v_id_content_stream := v_content_stream_id;
        end if;
        v_binary_content_length = p_binary_content_length;
        v_binary_content_hash := p_binary_content_hash;
        v_binary_content_hash_algorithm := p_binary_content_hash_algorithm;
        if p_binary_content_storage_mode = 'in_bytea' then
            v_binary_content_length = octet_length(p_binary_content);
            if v_binary_content_hash_algorithm is null then
                v_binary_content_hash_algorithm := 'sha512';
            end if;
            if v_binary_content_hash is null then
                v_binary_content_hash := digest(p_binary_content, v_binary_content_hash_algorithm::text);
            end if;
        end if;
    end if;

    -- Updating the data
    v_change_token := nextval('activity.id_change_log_seq');
    v_change_timestamp := now();

    if p_binary_content is not null then
        if v_content_stream_id is null then
            INSERT INTO activity.Content_Stream (
                id,
                length,
                mime_type,
                filename,
                binary_content,
                file_path,
                binary_content_storage_mode,
                binary_content_hash,
                binary_content_hash_algorithm,
                last_modified_by,
                last_modification_date
            )
            VALUES (
                v_id_content_stream,
                v_binary_content_length,
                p_mime_type,
                p_filename,
                p_binary_content,
                p_file_path,
                p_binary_content_storage_mode,
                v_binary_content_hash,
                v_binary_content_hash_algorithm,
                p_user,
                v_change_timestamp
            );
        else
            UPDATE activity.Content_Stream SET
                length = v_binary_content_length,
                mime_type = p_mime_type,
                filename = p_filename,
                binary_content = p_binary_content,
                file_path = p_file_path,
                binary_content_storage_mode = p_binary_content_storage_mode,
                binary_content_hash = v_binary_content_hash,
                binary_content_hash_algorithm = v_binary_content_hash_algorithm,
                last_modified_by = p_user,
                last_modification_date = v_change_timestamp
                WHERE id = v_id_content_stream;
        end if;
    end if;

    UPDATE activity.Object_Document SET
        content_stream_id = v_id_content_stream,
        last_modified_by = p_user,
        last_modification_date = v_change_timestamp,
        change_token = v_change_token
        WHERE id = p_id_document;

    if p_binary_content is null and v_content_stream_id is not null then
        DELETE FROM activity.Content_Stream WHERE id = v_content_stream_id;
    end if;

    INSERT INTO activity.Change_Log (
        id,
        change_timestamp,
        changed_by,
        change_type,
        changed_object_id,
        data
    )
    VALUES (
        v_change_token,
        v_change_timestamp,
        p_user,
        'updated',
        p_id_document,
        p_change_log_data
    );

end;
$fun$;

alter function update_document_content_stream(bigint, varchar, varchar, bytea, varchar, activity.storage_mode, bigint, bytea, activity.hash_algorithm, varchar, hstore) owner to postgres;

