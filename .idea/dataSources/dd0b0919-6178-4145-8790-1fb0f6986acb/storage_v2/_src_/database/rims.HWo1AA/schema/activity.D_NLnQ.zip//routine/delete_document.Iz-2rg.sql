create function delete_document(p_id_document bigint, p_user character varying, p_change_log_data hstore) returns void
  security definer
  language plpgsql
as
$fun$
declare
	v_document_id activity.Object_Document.id%type;
	v_content_stream_id activity.Object_Document.content_stream_id%type;
	v_change_token activity.Change_Log.id%type;
	v_change_timestamp activity.Change_Log.change_timestamp%type;
begin
	-- Locking the document
	PERFORM activity.lock_object(p_id_document, 'cmis:document');

	 -- Getting and checking the document information
	SELECT content_stream_id
		INTO v_content_stream_id
		FROM activity.Object_Document
		WHERE id = p_id_document;
	if not found then
		raise exception $$The document '%' does not exist$$, p_id_document;
	end if;

	-- Updating the data
	v_change_token := nextval('activity.id_change_log_seq');
	v_change_timestamp := now();

	DELETE FROM activity.Object_Document WHERE id = p_id_document;

	if v_content_stream_id is not null then
		DELETE FROM activity.Content_Stream WHERE id = v_content_stream_id;
	end if;

	INSERT INTO activity.Change_Log (
		id,
		change_timestamp,
		changed_by,
		change_type,
		changed_object_id,
		data
	)
	VALUES (
		v_change_token,
		v_change_timestamp,
		p_user,
		'deleted',
		p_id_document,
		p_change_log_data
	);

end;
$fun$;

alter function delete_document(bigint, varchar, hstore) owner to postgres;

