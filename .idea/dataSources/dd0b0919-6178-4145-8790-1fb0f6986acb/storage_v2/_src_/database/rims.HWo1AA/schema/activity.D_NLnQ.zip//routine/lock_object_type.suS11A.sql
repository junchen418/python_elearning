create function lock_object_type(p_id character varying) returns void
  security definer
  language plpgsql
as
$fun$
begin
    PERFORM id FROM activity.Object_Type WHERE id = p_id FOR UPDATE;
    if not found then
        raise exception $$The object type '%' does not exist$$, p_id;
    end if;
end;
$fun$;

alter function lock_object_type(varchar) owner to postgres;

