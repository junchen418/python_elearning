create function lock_property_type(p_id character varying) returns void
  security definer
  language plpgsql
as
$fun$
begin
    PERFORM id FROM activity.Property_Type_Basic WHERE id = p_id FOR UPDATE;
    if not found then
        raise exception $$The property type '%' does not exist$$, p_id;
    end if;
end;
$fun$;

alter function lock_property_type(varchar) owner to postgres;

