create function remove_old_delegations(p_change_log_changed_by character varying, p_change_log_data hstore) returns void
  security definer
  language plpgsql
as
$$
declare
    v_id_user users.User_Delegate_User_Link.id_user%type;
    v_id_delegate_user users.User_Delegate_User_Link.id_delegate_user%type;
begin
    for v_id_user, v_id_delegate_user in
        SELECT id_user, id_delegate_user
        FROM users.User_Delegate_User_Link
        WHERE delegation_end is not null and delegation_end < now() loop

        PERFORM users.remove_delegate_user_from_user(v_id_user, v_id_delegate_user, p_change_log_changed_by, p_change_log_data);
    end loop;
end;
$$;

alter function remove_old_delegations(varchar, hstore) owner to postgres;

