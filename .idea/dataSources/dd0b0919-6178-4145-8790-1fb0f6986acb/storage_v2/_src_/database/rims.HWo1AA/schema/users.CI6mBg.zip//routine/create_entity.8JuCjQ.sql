create function create_entity(p_id_entity character varying, p_name character varying, p_description text, p_parent_id character varying, p_attributes hstore, p_change_log_changed_by character varying, p_change_log_data hstore) returns users.entity_management_info
  security definer
  language plpgsql
as
$fun$
declare
    v_result users.entity_management_info;
    v_change_token users.Change_Log.id%type;
    v_change_timestamp users.Change_Log.change_timestamp%type;
begin
    -- Locking the parent entity if present
    if p_parent_id is not null then
        PERFORM users.lock_object(p_parent_id, 'entity');
    end if;
    
    -- Checking whether the entity ID is present
    if p_id_entity is null then
        raise exception $$The entity ID is mandatory$$;
    end if;
    
    -- Updating the data
    v_change_token := nextval('users.id_change_log_seq');
    v_change_timestamp := now();
    
    begin
        INSERT INTO users.Entity (
            id,
            name,
            description,
            parent_id,
            change_token,
            attributes
        )
        VALUES (
            p_id_entity,
            p_name,
            p_description,
            p_parent_id,
            v_change_token,
            p_attributes
        );
    exception
        when unique_violation then
            v_result := ROW('unavailable_entity_id');
            return v_result;
    end;
    
    INSERT INTO users.Change_Log (
        id,
        change_timestamp,
        changed_by,
        change_type,
        changed_object_id,
        changed_object_type,
        data
    )
    VALUES (
        v_change_token,
        v_change_timestamp,
        p_change_log_changed_by,
        'created',
        p_id_entity,
        'entity',
        p_change_log_data
    );
    
    v_result := ROW('entity_creation_success');
    return v_result;

end;
$fun$;

alter function create_entity(varchar, varchar, text, varchar, hstore, varchar, hstore) owner to postgres;

