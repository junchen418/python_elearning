create function create_property_type_index(p_table_name character varying, p_id_index bigint, p_id_property_type_basic character varying, p_property_type property_type, p_cardinality property_cardinality) returns void
  security definer
  language plpgsql
as
$$
declare
    v_index_name varchar;
    v_index_expression varchar;
begin
    v_index_name := 'IDX_HSTORE_' || substring(p_table_name from 12) || '_' || p_id_index::text; -- The 'activity.' schema prefix is removed
    if p_cardinality = 'single' and p_property_type != 'html' then
        if p_property_type = 'boolean' then
            v_index_expression := '((properties->' || quote_literal(p_id_property_type_basic) || ')::boolean)';
        elsif p_property_type = 'decimal' then
            v_index_expression := '((properties->' || quote_literal(p_id_property_type_basic) || ')::decimal)';
        elsif p_property_type = 'integer' then
            v_index_expression := '((properties->' || quote_literal(p_id_property_type_basic) || ')::bigint)';
        elsif p_property_type = 'datetime' then
            v_index_expression := 'activity.to_timestamp((properties->' || quote_literal(p_id_property_type_basic) || ')::varchar)';
        else
            v_index_expression := '(properties->' || quote_literal(p_id_property_type_basic) || ')';
        end if;
        EXECUTE 'CREATE INDEX ' || v_index_name || ' ON ' || p_table_name || ' USING btree (' || v_index_expression || ')';
    else
        if p_property_type = 'boolean' then
            v_index_expression := 'activity.to_array_of_boolean(properties->' || quote_literal(p_id_property_type_basic) || ')';
        elsif p_property_type = 'decimal' then
            v_index_expression := 'activity.to_array_of_decimal(properties->' || quote_literal(p_id_property_type_basic) || ')';
        elsif p_property_type = 'integer' then
            v_index_expression := 'activity.to_array_of_bigint(properties->' || quote_literal(p_id_property_type_basic) || ')';
        elsif p_property_type = 'datetime' then
            v_index_expression := 'activity.to_array_of_timestamp(properties->' || quote_literal(p_id_property_type_basic) || ')';
        elsif p_property_type = 'html' then
            v_index_expression := 'activity.to_tsvector(properties->' || quote_literal(p_id_property_type_basic) || ')';
        else
            v_index_expression := 'activity.to_array_of_text(properties->' || quote_literal(p_id_property_type_basic) || ')';
        end if;
        EXECUTE 'CREATE INDEX ' || v_index_name || ' ON ' || p_table_name || ' USING gin (' || v_index_expression || ')';
    end if;
end;
$$;

alter function create_property_type_index(varchar, bigint, varchar, property_type, property_cardinality) owner to postgres;

